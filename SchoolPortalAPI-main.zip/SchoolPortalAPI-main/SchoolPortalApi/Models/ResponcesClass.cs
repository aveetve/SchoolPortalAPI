﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolPortalApi.Models
{
    public class ResponcesUsers
    {
        public string Role { get; set; }
        public int NextId { get; set; }
    }
}