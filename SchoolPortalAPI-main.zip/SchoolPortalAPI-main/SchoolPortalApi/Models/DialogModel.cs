﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SchoolPortalApi.Models
{
    public class DialogModel
    {
        public int id { get; set; }
        public int idFirstUser { get; set; }
        public int idSecondUser { get; set; }
    }
}